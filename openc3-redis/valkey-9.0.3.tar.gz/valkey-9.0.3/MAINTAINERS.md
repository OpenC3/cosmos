## Overview

This document contains a list of maintainers in this repo.
See [GOVERNANCE.md](GOVERNANCE.md) that explains the function of this file.

## Current Maintainers

Maintainers listed in alphabetical order by their github ID.

| Maintainer          | GitHub ID                                       | Affiliation |
| ------------------- | ----------------------------------------------- | ----------- |
| Zhu Binbin          | [enjoy-binbin](https://github.com/enjoy-binbin) | Tencent     |
| Wen Hui             | [hwware](https://github.com/hwware)             | Huawei      |
| Madelyn Olson       | [madolson](https://github.com/madolson)         | Amazon      |
| Ping Xie            | [pingxie](https://github.com/pingxie)           | Google      |
| Zhao Zhao           | [soloestoy](https://github.com/soloestoy)       | Alibaba     |
| Viktor Söderqvist   | [zuiderkwast](https://github.com/zuiderkwast)   | Ericsson    |

## Current Committers

Committers listed in alphabetical order by their github ID.

| Committer           | GitHub ID                                       | Affiliation |
| ------------------- | ----------------------------------------------- | ----------- |
| Harkrishn Patro     | [hpatro](https://github.com/hpatro)             | Amazon      |
| Jacob Murphy        | [murphyjacob4](https://github.com/murphyjacob4) | Google      |
| Ran Shidlansik      | [ranshid](https://github.com/ranshid)           | Amazon      |
| Ricardo Dias        | [rjd15372](https://github.com/rjd15372)         | Percona     |

### Former Maintainers and Committers 

| Maintainer          | GitHub ID                                       | Affiliation |
| ------------------- | ----------------------------------------------- | ----------- |