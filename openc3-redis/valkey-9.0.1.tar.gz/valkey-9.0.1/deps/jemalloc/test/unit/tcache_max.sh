#!/bin/sh

export MALLOC_CONF="tcache_max:1024"
