#ifndef HEADER_FileDescriptorMeter
#define HEADER_FileDescriptorMeter
/*
htop - FileDescriptorMeter.h
(C) 2022 htop dev team
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/

#include "Meter.h"


extern const MeterClass FileDescriptorMeter_class;

#endif
