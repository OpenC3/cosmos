

// Use POSIX implementation
#include "../posix/csp_time.c"
