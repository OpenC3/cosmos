

#pragma once

#include <csp/csp_types.h>

csp_socket_t * csp_port_get_socket(unsigned int dport);
csp_callback_t csp_port_get_callback(unsigned int port);
