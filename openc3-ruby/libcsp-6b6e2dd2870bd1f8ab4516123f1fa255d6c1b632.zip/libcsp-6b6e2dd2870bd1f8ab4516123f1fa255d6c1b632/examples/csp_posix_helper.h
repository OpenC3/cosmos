#pragma once

int router_start(void);
int csp_pthread_create(void * (*routine)(void *));
