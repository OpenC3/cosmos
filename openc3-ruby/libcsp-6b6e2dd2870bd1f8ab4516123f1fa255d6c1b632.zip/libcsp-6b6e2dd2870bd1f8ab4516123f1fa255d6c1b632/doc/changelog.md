# Changelog

## Latest Changes

```{eval-rst}
.. git_commit_detail::
    :branch:
    :commit:

.. git_changelog::
  :revisions: 50
```
