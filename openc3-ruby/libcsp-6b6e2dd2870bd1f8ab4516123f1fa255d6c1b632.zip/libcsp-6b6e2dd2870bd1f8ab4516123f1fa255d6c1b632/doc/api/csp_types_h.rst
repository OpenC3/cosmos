CSP Basic Types
===============

.. Nested structures (such as csp_packet_s) are not parsed properly

.. autocmodule:: csp_types.h
    :members:
