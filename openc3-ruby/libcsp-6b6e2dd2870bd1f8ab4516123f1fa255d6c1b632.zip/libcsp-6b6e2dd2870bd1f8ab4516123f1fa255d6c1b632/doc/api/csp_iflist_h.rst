Interfaces management
=====================

.. autocmodule:: csp_iflist.h

Interface Functions
-------------------

.. autocfunction:: csp_iflist.h::csp_iflist_add
.. autocfunction:: csp_iflist.h::csp_iflist_remove
.. autocfunction:: csp_iflist.h::csp_bytesize
.. autocfunction:: csp_iflist.h::csp_iflist_check_dfl
