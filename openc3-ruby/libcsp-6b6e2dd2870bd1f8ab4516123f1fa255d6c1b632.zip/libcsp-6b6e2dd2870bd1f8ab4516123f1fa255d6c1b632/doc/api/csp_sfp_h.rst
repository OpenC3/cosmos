Small Fragmentation Protocol (SFP)
==================================

.. autocmodule:: csp_sfp.h

Interface Functions
-------------------

.. autocfunction:: csp_sfp.h::csp_sfp_send_own_memcpy
.. autocfunction:: csp_sfp.h::csp_sfp_send
.. autocfunction:: csp_sfp.h::csp_sfp_recv_fp
.. autocfunction:: csp_sfp.h::csp_sfp_recv
