Promiscuous packet queue
========================

.. autocmodule:: csp_promisc.h

Interface Functions
-------------------

.. autocfunction:: csp_promisc.h::csp_promisc_enable
.. autocfunction:: csp_promisc.h::csp_promisc_disable
.. autocfunction:: csp_promisc.h::csp_promisc_read
