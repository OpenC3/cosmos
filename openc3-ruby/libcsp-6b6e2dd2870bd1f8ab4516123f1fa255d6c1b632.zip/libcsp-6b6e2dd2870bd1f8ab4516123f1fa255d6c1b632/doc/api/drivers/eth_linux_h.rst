Posix ETH driver
================

.. autocmodule:: drivers/eth_linux.h

Interface Functions
-------------------

.. autocfunction:: drivers/eth_linux.h::csp_eth_init
.. autocfunction:: drivers/eth_linux.h::csp_eth_tx_frame
.. autocfunction:: drivers/eth_linux.h::csp_eth_rx_loop
