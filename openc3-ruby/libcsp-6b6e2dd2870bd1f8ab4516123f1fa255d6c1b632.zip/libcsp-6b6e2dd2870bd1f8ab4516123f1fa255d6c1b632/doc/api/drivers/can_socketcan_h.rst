Socket CAN driver (Linux)
=========================

.. autocmodule:: drivers/can_socketcan.h

Interface Functions
-------------------

.. autocfunction:: drivers/can_socketcan.h::csp_can_socketcan_open_and_add_interface
.. autocfunction:: drivers/can_socketcan.h::csp_can_socketcan_init
.. autocfunction:: drivers/can_socketcan.h::csp_can_socketcan_stop
