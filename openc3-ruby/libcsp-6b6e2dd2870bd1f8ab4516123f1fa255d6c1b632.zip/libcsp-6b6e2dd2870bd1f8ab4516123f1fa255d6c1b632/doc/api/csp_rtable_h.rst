Routing table
=============

.. autocmodule:: csp_rtable.h

Interface Functions
-------------------

.. autocfunction:: csp_rtable.h::csp_rtable_search_backward
.. autocfunction:: csp_rtable.h::csp_rtable_find_route
.. autocfunction:: csp_rtable.h::csp_rtable_set
.. autocfunction:: csp_rtable.h::csp_rtable_save
.. autocfunction:: csp_rtable.h::csp_rtable_load
.. autocfunction:: csp_rtable.h::csp_rtable_check
.. autocfunction:: csp_rtable.h::csp_rtable_clear
.. autocfunction:: csp_rtable.h::csp_rtable_free
.. autocfunction:: csp_rtable.h::csp_rtable_iterate
.. autocfunction:: csp_rtable.h::csp_rtable_print
