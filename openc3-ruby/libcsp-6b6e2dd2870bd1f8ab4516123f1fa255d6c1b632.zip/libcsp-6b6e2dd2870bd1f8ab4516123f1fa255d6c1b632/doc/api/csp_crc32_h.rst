CRC32 Support
=============

.. autocmodule:: csp_crc32.h

Interface Functions
-------------------

.. autocfunction:: csp_crc32.h::csp_crc32_append
.. autocfunction:: csp_crc32.h::csp_crc32_verify
.. autocfunction:: csp_crc32.h::csp_crc32_memory
