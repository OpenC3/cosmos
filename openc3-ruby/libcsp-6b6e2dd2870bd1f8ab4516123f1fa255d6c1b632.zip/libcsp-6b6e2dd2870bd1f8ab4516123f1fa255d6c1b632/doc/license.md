# License

```{eval-rst}
.. include:: ../LICENSE
   :parser: myst_parser.sphinx_
```
