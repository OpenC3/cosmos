# Continuous Integration

libcsp uses [GitHub Actions](https://github.com/features/actions) for continuous
integration. The current available actions can be found [here](https://github.com/libcsp/libcsp/actions).
