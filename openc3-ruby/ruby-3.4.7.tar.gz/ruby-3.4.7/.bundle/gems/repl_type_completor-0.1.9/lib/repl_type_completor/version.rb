# frozen_string_literal: true

module ReplTypeCompletor
  VERSION = "0.1.9"
end
